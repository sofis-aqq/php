<?php
	$host = "localhost";
	$usuario = "root";
	$senha = "";
	$banco = "lojinha";

	$conex = new MySQLi("$host", "$usuario", "$senha","$banco");
	if ($conex -> connect_error){
		echo "Erro";
	} else{
		echo "Conectado";
	}
	
?>