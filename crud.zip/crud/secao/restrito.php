<?php
 	session_start();
	

	if ((!isset($_SESSION['id'])==true)&&
		(!isset($_SESSION['nome'])==true)&&
		(!isset($_session['email'])==true)) {
		unset($_SESSION['id']);
		unset($_SESSION['nome']);
		unset($_SESSION['email']);

		header('location:login/index.html');

	}

	echo 'nao vai passar nao';
?>
<br>
<link rel="stylesheet" type="text/css" href="css/main.css">
<a href="saida.php" class="container-login100-form-btn">Saindo</a>
